﻿using Halite2.hlt;
using System.Collections.Generic;

namespace Halite2
{
  public class MyBot
  {

    public static void Main(string[] args)
    {
      string name = args.Length > 0 ? args[0] : "Sharpie";

      Networking networking = new Networking();
      GameMap gameMap = networking.Initialize(name);
      Planet largestPlanet;

      List<Planet> selectedPlanets = new List<Planet>();

      List<Move> moveList = new List<Move>();
      for (; ; )
      {
        moveList.Clear();
        gameMap.UpdateMap(Networking.ReadLineIntoMetadata());

        foreach (Ship ship in gameMap.GetMyPlayer().GetShips().Values)
        {

          if (ship.GetDockingStatus() != Ship.DockingStatus.Undocked)
          {
            continue;
          }

          foreach (Planet planet in gameMap.GetAllPlanets().Values)
          {
            if (planet.IsOwned())
            {
              continue;
            }

            largestPlanet = planet;

            if (planet.GetRadius() > largestPlanet.GetRadius())
            {
              if (planet.GetDistanceTo(ship) < largestPlanet.GetDistanceTo(ship))
              {
                largestPlanet = planet;
              }
            }

            foreach (Planet sPlanet in selectedPlanets)
            {
              if (sPlanet == largestPlanet)
                goto hello;
            }

            if (ship.CanDock(largestPlanet))
            {             
              moveList.Add(new DockMove(ship, largestPlanet));
              selectedPlanets.Add(largestPlanet);
              break;
            }
            else
            {
              ThrustMove newLThrustMove = Navigation.NavigateShipToDock(gameMap, ship, largestPlanet, Constants.MAX_SPEED);
              if (newLThrustMove != null)
              {
                moveList.Add(newLThrustMove);
                break;
              }
            }
          }
        }
        hello:
        Networking.SendMoves(moveList);
      }
    }
  }
}
